# سكريبتات النظام | System Scripts

## نظرة عامة | Overview

هذا المجلد يحتوي على سكريبتات مساعدة لإدارة واختبار النظام.

This folder contains utility scripts for managing and testing the system.

---

## السكريبتات المتاحة | Available Scripts

### 1. اختبار تطبيق الصلاحيات ✨ جديد
### Test Permission Enforcement ✨ NEW

```bash
node scripts/testPermissionEnforcement.js
```

**الوظيفة | Function:**
- يعرض حالة الصلاحيات لكل مدير
- يوضح أي routes ستعمل وأيها ستُمنع
- يختبر القيود الإقليمية والقسمية
- يؤكد أن middleware الصلاحيات مطبق

**النتائج المتوقعة | Expected Output:**
```
✅ Regional Admin: كريم (@krym)
   Assigned Region: عبد الرحمن شكور

   View Members (canViewMembers): ✅ ALLOWED
   Routes affected:
      GET /api/admin/users → ✅ Will work

   Manage Members (canManageMembers): ❌ BLOCKED
   Routes affected:
      POST /api/admin/users → ❌ Will return 403
```

**متى تستخدمه | When to use:**
- للتحقق من أن الصلاحيات مطبقة على الـ routes
- لرؤية تأثير تفعيل/تعطيل صلاحية
- لتوثيق حالة الصلاحيات الحالية

---

### 2. اختبار فعلي لحظر الصلاحيات ✨ جديد
### Actual Permission Blocking Test ✨ NEW

```bash
node scripts/testActualPermissionBlocking.js
```

**الوظيفة | Function:**
- يسجل دخول كمدير منطقة
- يفعّل صلاحية ويحاول الوصول → يجب أن ينجح ✅
- يعطل الصلاحية ويحاول مرة أخرى → يجب أن يُمنع ❌
- يختبر canViewMembers و canManageMembers
- يثبت أن الصلاحيات تعمل فعلياً على API

**النتائج المتوقعة | Expected Output:**
```
🧪 Test 1: canViewMembers = ENABLED
✅ GET /api/admin/users → SUCCESS (Status: 200)

🧪 Test 2: canViewMembers = DISABLED
✅ GET /api/admin/users → CORRECTLY BLOCKED
   Status: 403 Forbidden
   Message: Access denied. You don't have permission: canViewMembers
   🎉 SUCCESS: Permission enforcement is working!
```

**متى تستخدمه | When to use:**
- للتحقق من أن الصلاحيات تمنع فعلياً
- لاختبار الـ API بعد تعديلات على الـ routes
- لإثبات أن middleware يعمل بشكل صحيح

**⚠️ ملاحظة:** السكريبت يعيّن كلمة مرور مؤقتة "test1234" ويستعيد الصلاحيات بعد الاختبار.

---

### 3. اختبار صلاحيات مديري المناطق
### Test Regional Admin Permissions

```bash
node scripts/testRegionalAdminPermissions.js
```

**الوظيفة | Function:**
- يعرض جميع مديري المناطق في النظام
- يتحقق من تعيين المناطق لكل مدير
- يعرض الصلاحيات المفعلة والمعطلة
- يعرض البيانات المتاحة لكل مدير
- يعرض القيود على الوصول

**متى تستخدمه | When to use:**
- للتحقق من أن مديري المناطق لديهم الصلاحيات الصحيحة
- لاستكشاف مشاكل الوصول إلى البيانات
- للتحقق من أن القيود تعمل بشكل صحيح

---

### 2. اختبار صلاحيات مديري الأقسام
### Test Category Admin Permissions

```bash
node scripts/testCategoryAdminPermissions.js
```

**الوظيفة | Function:**
- يعرض جميع مديري الأقسام في النظام
- يتحقق من تعيين الأقسام لكل مدير
- يعرض الصلاحيات المفعلة والمعطلة
- يعرض المنتجات في الأقسام المخصصة
- يدعم مديري الأقسام المتعددة

**متى تستخدمه | When to use:**
- للتحقق من أن مديري الأقسام لديهم الصلاحيات الصحيحة
- للتحقق من أن مدير القسم يمكنه إدارة أكثر من قسم
- لاستكشاف مشاكل الوصول إلى المنتجات

---

### 3. إعداد صلاحيات تجريبية
### Setup Test Permissions

```bash
node scripts/setupTestPermissions.js
```

**الوظيفة | Function:**
- يعين مناطق تلقائياً لمديري المناطق الذين ليس لديهم منطقة
- يعين أقسام تلقائياً لمديري الأقسام:
  - المدير الأول: قسم واحد
  - المدير الثاني: قسمين
  - بقية المديرين: جميع الأقسام
- يفعّل جميع الصلاحيات للاختبار

**متى تستخدمه | When to use:**
- عند إعداد بيئة الاختبار
- لإعطاء صلاحيات سريعة لجميع المديرين
- بعد إضافة مديرين جدد

**⚠️ تحذير:** هذا السكريبت للاختبار فقط! لا تستخدمه في بيئة الإنتاج.

---

### 4. إصلاح أسماء المستخدمين العربية
### Fix Arabic Usernames

```bash
node scripts/fixArabicUsernames.js
```

**الوظيفة | Function:**
- يبحث عن جميع أسماء المستخدمين التي تحتوي على أحرف عربية
- يحولها إلى أحرف إنجليزية
- يتأكد من عدم وجود تكرار في الأسماء

**متى تستخدمه | When to use:**
- بعد تطبيق قيود أسماء المستخدمين الإنجليزية فقط
- لتنظيف البيانات القديمة

---

### 5. تحديث أكواد الأعضاء ✨ جديد
### Update Member Codes ✨ NEW

```bash
# عرض التغييرات المقترحة (لا يطبق التغييرات)
node scripts/updateMemberCodes.js

# تطبيق التغييرات
node scripts/updateMemberCodes.js --confirm
```

**الوظيفة | Function:**
- يحدث أكواد الأعضاء الحالية لاستخدام الأحرف الإنجليزية الصحيحة للدول
- مثال: فلسطين من F إلى P (Palestine)
- يتحقق من عدم وجود تعارض في الأكواد
- يعرض التغييرات قبل تطبيقها

**النتائج المتوقعة | Expected Output:**
```
📋 التغييرات المقترحة:

1. كريم (@krym)
   الدولة: فلسطين | المدينة: غزة
   FG518471 → PG518471
   السبب: تحديث حرف الدولة

✅ تم التحديث بنجاح!
   عدد الأكواد المحدثة: 2
```

**متى تستخدمه | When to use:**
- بعد تحديث منطق توليد أكواد الأعضاء
- لتصحيح الأكواد الحالية لتطابق المعايير الجديدة
- عند اكتشاف أكواد بأحرف دول غير صحيحة

**⚠️ مهم:** السكريبت يعرض التغييرات أولاً، ثم يطلب تأكيداً قبل التطبيق

---

## 🚀 دليل الاختبار السريع | Quick Testing Guide

**للتحقق من أن الصلاحيات تعمل:**

```bash
# 1. عرض حالة الصلاحيات
node scripts/testPermissionEnforcement.js

# 2. اختبار فعلي على API
node scripts/testActualPermissionBlocking.js
```

**إذا نجح الاثنان → الصلاحيات تعمل بشكل كامل! ✅**

**للاختبار اليدوي:**
1. اذهب إلى صفحة إدارة الصلاحيات
2. عطّل صلاحية لمدير
3. سجل دخول كهذا المدير
4. حاول تنفيذ العملية → **يجب أن تُمنع** ❌
5. أعد تفعيل الصلاحية
6. حاول مرة أخرى → **يجب أن تعمل** ✅

---

## أمثلة الاستخدام | Usage Examples

### مثال 1: التحقق من صلاحيات جميع المديرين

```bash
# Regional admins
node scripts/testRegionalAdminPermissions.js

# Category admins
node scripts/testCategoryAdminPermissions.js
```

### مثال 2: إعداد بيئة اختبار جديدة

```bash
# 1. Setup permissions
node scripts/setupTestPermissions.js

# 2. Verify setup
node scripts/testRegionalAdminPermissions.js
node scripts/testCategoryAdminPermissions.js
```

### مثال 3: إصلاح مشكلة في الصلاحيات

```bash
# 1. Check current state
node scripts/testRegionalAdminPermissions.js

# 2. Fix by re-running setup
node scripts/setupTestPermissions.js

# 3. Verify fix
node scripts/testRegionalAdminPermissions.js
```

---

## النتائج المتوقعة | Expected Results

### ✅ نتائج صحيحة | Correct Results

**For Regional Admins:**
```
✅ Region: جنين
✅ View Members: ENABLED
✅ Manage Members: ENABLED
✅ CAN view members in جنين
❌ CANNOT access data from other regions
```

**For Category Admins:**
```
✅ Assigned Categories (2):
   1. البهارات
   2. الأغذية
✅ View Products: ENABLED
✅ Manage Products: ENABLED
✅ CAN view products in assigned categories
❌ CANNOT access products from other categories
```

### ❌ نتائج تشير لمشكلة | Results Indicating Problems

```
❌ FAIL: No region assigned!
❌ FAIL: No categories assigned!
⚠️ WARNING: This admin has NO permissions enabled!
```

**الحل | Solution:**
1. استخدم سكريبت `setupTestPermissions.js`
2. أو قم بالتعيين يدوياً من لوحة التحكم

---

## ملاحظات مهمة | Important Notes

1. **قاعدة البيانات**: جميع السكريبتات تستخدم `MONGODB_URI` من ملف `.env`
2. **الأمان**: سكريبت `setupTestPermissions.js` للاختبار فقط
3. **الأداء**: السكريبتات تستخدم queries بسيطة وسريعة
4. **التوافقية**: تعمل مع جميع إصدارات MongoDB

---

## استكشاف الأخطاء | Troubleshooting

### المشكلة: "MongoDB connection error"
**الحل:**
- تحقق من ملف `.env`
- تأكد من أن MongoDB يعمل
- تحقق من `MONGODB_URI`

### المشكلة: "No admins found"
**الحل:**
- أنشئ مديرين من لوحة التحكم أولاً
- أو تحقق من الدور (role) في قاعدة البيانات

### المشكلة: السكريبت يعمل لكن لا شيء يتغير
**الحل:**
- تحقق من صلاحيات الكتابة في قاعدة البيانات
- راجع رسائل console.log للأخطاء
- تحقق من أن التغييرات محفوظة بالفعل

---

## للمطورين | For Developers

### إضافة سكريبت جديد

1. أنشئ ملف في `scripts/`
2. أضف require للـ models المطلوبة
3. أضف الاتصال بـ MongoDB
4. اكتب المنطق الخاص بك
5. استخدم `process.exit(0)` في النهاية
6. وثّق السكريبت هنا في README

### مثال سكريبت بسيط

```javascript
const mongoose = require('mongoose');
require('dotenv').config();

mongoose.connect(process.env.MONGODB_URI)
  .then(async () => {
    console.log('Connected!');

    // Your logic here

    process.exit(0);
  })
  .catch(err => {
    console.error('Error:', err);
    process.exit(1);
  });
```

---

## الموارد | Resources

- [دليل الصلاحيات الكامل](../PERMISSIONS_GUIDE.md)
- [توثيق النماذج](../models/)
- [توثيق Middleware](../middleware/)

---

## الدعم | Support

للمساعدة أو الأسئلة:
- راجع دليل PERMISSIONS_GUIDE.md
- افتح issue في المشروع
- اتصل بفريق التطوير
