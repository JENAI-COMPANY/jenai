import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { getCategories } from '../services/api';
import { useLanguage } from '../context/LanguageContext';
import gsap from 'gsap';
import '../styles/CategorySlider.css';

const CategorySlider = () => {
  const { language } = useLanguage();
  const [categories, setCategories] = useState([]);
  const sliderRef = useRef(null);
  const animationRef = useRef(null);

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    if (categories.length > 0 && sliderRef.current) {
      startAnimation();
    }
    return () => {
      if (animationRef.current) {
        animationRef.current.kill();
      }
    };
  }, [categories]);

  const fetchCategories = async () => {
    try {
      const data = await getCategories();
      // Ensure categories is always an array of objects with proper structure
      const categoriesData = (data.categories || []).map(cat => {
        if (typeof cat === 'string') {
          return { name: cat, nameAr: cat, nameEn: cat, image: '' };
        }
        return {
          ...cat,
          name: cat.name || cat.nameAr || cat.nameEn || '',
          nameAr: cat.nameAr || cat.name || '',
          nameEn: cat.nameEn || cat.name || ''
        };
      });
      setCategories(categoriesData);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const startAnimation = () => {
    const slider = sliderRef.current;
    const items = slider.children;
    const totalWidth = slider.scrollWidth / 2;

    gsap.set(slider, { x: 0 });

    animationRef.current = gsap.to(slider, {
      x: -totalWidth,
      duration: 20,
      ease: 'none',
      repeat: -1,
    });
  };

  const handleMouseEnter = () => {
    if (animationRef.current) {
      animationRef.current.pause();
    }
  };

  const handleMouseLeave = () => {
    if (animationRef.current) {
      animationRef.current.resume();
    }
  };

  if (categories.length === 0) return null;

  // Duplicate categories for seamless loop
  const duplicatedCategories = [...categories, ...categories];

  return (
    <section className="category-slider-section">
      <div className="category-slider-header">
        <h2>{language === 'ar' ? 'تصفح الأقسام' : 'Browse Categories'}</h2>
        <p>{language === 'ar' ? 'اختر القسم الذي يناسبك' : 'Choose your preferred category'}</p>
      </div>

      <div
        className="category-slider-container"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        <div className="category-slider" ref={sliderRef}>
          {duplicatedCategories.map((category, index) => (
            <Link
              key={`category-${index}`}
              to={`/products-page?category=${encodeURIComponent(category.name)}`}
              className="category-circle"
            >
              <div className="category-circle-inner">
                {category.image && (
                  <img src={category.image} alt={language === 'ar' ? category.nameAr : category.nameEn} className="category-image" />
                )}
                <span className="category-name">
                  {language === 'ar' ? category.nameAr : category.nameEn}
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategorySlider;
